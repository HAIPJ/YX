import React from 'react'
import {View, Text, ScrollView, Button, StyleSheet} from 'react-native'
import MySlides from './MySlides';
import MyProductDetail from './MyProductDetail';

export default class ProductDetailScreen extends React.Component{
  /*对象属性*/
  static navigationOptions = { title: '商品详情' }
  static productDetailUrl = 'http://www.codeboy.com/data/product/details.php?lid='

  /*对象构造方法*/
  constructor(){
    super()
    this.state = {
      product: {} //要绑定的商品数据
    }
  }

  /*对象方法*/
  componentDidMount(){
    //获取上一页面传递来的路由参数：pid
    let pid = this.props.navigation.getParam('pid')
    //发起异步请求，获取商品数据
    let url = ProductDetailScreen.productDetailUrl+pid
    fetch(url)
      .then((res)=>{ return res.json()})
      .then((result)=>{
        this.setState({
          product: result.details
        })
      })
      .catch((err)=>{console.log(err)})
  }
  render(){
    return (
      <View style={{flex:1, padding: 10}}>
        <ScrollView>
          <Text>商品型号：{this.state.product.lname}</Text>
          <View style={ss.hr}></View>
          {/* 在“详情组件(父)”中使用“轮播组件(子)” */}
          <MySlides picList={this.state.product.picList}/>
  
          <Text>{this.state.product.title}</Text>
          <Text>{this.state.product.subtitle}</Text>
          <Text>单价：{this.state.product.price}</Text>
          <View style={ss.hr}></View>

          {/* 把服务器端获得的商品详情(html标签)渲染在自定义组件中 */}
          <MyProductDetail content={this.state.product.details}/>
        </ScrollView>
        <Button title="删除商品"/>
      </View>
    )
  }
}

let ss = StyleSheet.create({
  hr: {
    height: 1,
    backgroundColor: '#888',
    marginVertical: 10
  }
})