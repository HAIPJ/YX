import React from 'react'
import {ScrollView, View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native'

export default class MainScreen extends React.Component{
  /*对象属性*/
  static navigationOptions = {
    title: '主菜单',
    //headerTitle: <Image />  
    headerRight: (
      <TouchableOpacity onPress={()=>{}}>
        <Image source={require('../assets/user.png')} style={{width:36,height:36, borderRadius: 18}}/>
      </TouchableOpacity>
    )
  }

  /*对象构造方法*/
  constructor(){
    super()
    this.state = {

    }
  }

  /*对象方法*/
  render(){
    return (
      <ScrollView>
        {/* 统计相关组件 */}
        <View>
          <View style={ss.row}>
            <View style={ss.col}>
              <Text>行1列1</Text>
            </View>
            <View style={ss.col}>
              <Text>行1列2</Text>
            </View>
          </View>
          <View style={ss.row}>
            <View style={ss.col}>
              <Text>行2列1</Text>
            </View>
            <View style={ss.col}>
              <Text>行2列2</Text>
            </View>
          </View>
          <View style={ss.row}>
            <View style={ss.col}>
              <Text>行3列1</Text>
            </View>
            <View style={ss.col}>
              <Text>行3列2</Text>
            </View>
          </View>
        </View>

        {/* 功能菜单相关组件*/}
        <View style={{marginTop: 50}}>
          <View style={ss.row}>
            <View style={[ss.col, {borderWidth:0}]}>
              <TouchableOpacity onPress={()=>this.props.navigation.navigate('productList')}>
                <Text>商品管理</Text>
              </TouchableOpacity>
            </View>
            <View style={[ss.col, {borderWidth:0}]}>
              <Text>行1列2</Text>
            </View>
          </View>
          <View style={ss.row}>
            <View style={[ss.col, {borderWidth:0}]}>
              <Text>行2列1</Text>
            </View>
            <View style={[ss.col, {borderWidth:0}]}>
              <Text>行2列2</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    )
  }
}

let ss = StyleSheet.create({
  row: {
    flexDirection: 'row'
  },
  col: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    borderColor: '#888',
    borderWidth: 1
  }
})