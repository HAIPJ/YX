import React from 'react'
import {Text, View, Image, StyleSheet, Dimensions} from 'react-native'

export default class MyProductDetail extends React.Component{
  constructor(){
    super()
    this.state = {
    }
  }

  render(){
    if(this.props.content){
      //content属性已经获得了服务器端的数据
      //this.props.content形如：
      /*
        <div class="content_tpl"><div class="formwork">
        <div class="formwork_img">
        <img class="" src="img/product/detail/59190fe7N6a9fb112.jpg">
        <img class="" src="img/product/detail/58d0bfceNc0694135.jpg">
        </div>
      */
      let arr = this.props.content.match(/img\/\S+\.jpg/g)
      return (
        <View>
          {
            arr.map((url, i)=>{
              /*
              Image.getSize(url, (w, h)=>{
                //w就是远程图片的宽，h就是远程图片的高度
              })
              */
              return <Image style={ss.full} source={{uri:'http://www.codeboy.com/'+url}}/>
            })
          }
        </View>
      )
    }else {
      //content尚未获得服务器端数据
      return <Text>商品详情加载中...</Text>
    }
  }
}
let ss = StyleSheet.create({
  full: {   //一个宽和高都是“窗口宽度”的组件
    width: Dimensions.get('window').width-20,
    height: 400,
  }
})