import React from 'react'
import {View, Text, Button, TextInput, Image, StyleSheet} from 'react-native'

export default class LoginScreen extends React.Component{
  /*对象属性*/
  static navigationOptions = {
    title: '管理员登录'
  }

  /*对象构造方法*/
  constructor(){
    super()
    this.state = {
      adminName: '',
      adminPwd: '',
    }
  }

  /*对象方法*/
  onAdminNameChange=(val)=>{
    this.setState({adminName: val})
  }
  onAdminPwdChange=(val)=>{
    this.setState({adminPwd: val})
  }
  doLogin=()=>{
    let aname = this.state.adminName;
    let apwd = this.state.adminPwd;
    //发起异步的服务器API请求，进行登录验证  
    let loginUrl='http://www.codeboy.com/data/user/login.php'
    fetch(loginUrl, {
      method: 'POST',
      headers: {
        'Content-Type':'application/x-www-form-urlencoded'
      },
      body: `uname=${aname}&upwd=${apwd}`
    })
      .then((res)=>{return res.json()})
      .then((result)=>{
        if(result.code===200){
          //登录成功，跳转到主界面
          this.props.navigation.navigate('main')
        }else {
          //登录失败
          alert(result.msg)
        }
      })
      .catch((err)=>{console.log(err)})
  }
  render(){
    return (
      <View style={ss.container}>
        <TextInput value={this.state.adminName} onChangeText={this.onAdminNameChange} style={ss.input} placeholder="请输入管理员用户名"/>
        <TextInput value={this.state.adminPwd} onChangeText={this.onAdminPwdChange} style={ss.input} placeholder="请输入管理登录密码" secureTextEntry={true}/>
        
        <Button title="登录" onPress={this.doLogin}/>
        
        <View style={ss.box}>
          <Image source={require('../assets/logo.png')}/>
          <Text style={ss.appTitle}>后台管理系统</Text>
        </View>
        <Text style={ss.copyright}>©2017 版权所有，CODEBOY.COM</Text>
      </View>
    )
  }
}

let ss = StyleSheet.create({
  container: {        //最外层容器
    padding: 30
  },
  input: {            //输入框
    borderBottomColor: '#888',
    borderBottomWidth: 1,
    marginBottom: 20
  },
  box: {             //logo和应用名称的盒子
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginVertical: 50
  },
  appTitle: {         //应用名称：“后台管理系统”
    fontSize: 25,
    color: '#73879c'
  },
  copyright: {        //版权声明
    color: '#73879c',
    textAlign: 'center'
  }
})