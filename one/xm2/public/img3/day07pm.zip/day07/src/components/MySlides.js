import React from 'react'
import {View, Image, StyleSheet, Dimensions} from 'react-native'

export default class MySlides extends React.Component{
  static serverUrl = 'http://www.codeboy.com/'
  timer = null    //轮播广告定时器

  constructor(){
    super()
    this.state = {
      curIndex: 0   //图片数组中当前显示的图片下标
    }
  }

  componentWillUnmount(){
    //will  unmount：即将被卸载——执行资源释放性语句
    if(this.timer){
      clearInterval(this.timer)
    }
  }
  render(){
    if(this.props.picList){
      // console.log('轮播广告有图片数据了')
      //服务器端返回了数据，父组件已经把图片列表传给当前轮播组件
      //启用定时器，开始轮播：启动定时器——只启动一次
      if(this.timer===null){
        this.timer = setInterval(()=>{
            //定时器任务：修改要显示图片的下标
            let i = this.state.curIndex;
            i++;   
            if(i>=this.props.picList.length){
                i = 0;    //已经播完一轮，重回第一张
            }
            this.setState({curIndex: i})
        }, 1000)
      }
      return (
        <Image style={ss.full} source={{uri: MySlides.serverUrl + this.props.picList[this.state.curIndex].md}} resizeMode="stretch"/>
      )
    }else {
      // console.log('轮播广告尚无图片数据')
      return (
        <Image style={ss.full} source={require('../assets/loading.jpg')} resizeMode="stretch"/>
      )
    }
  }
}

let ss = StyleSheet.create({
  full: {   //一个宽和高都是“窗口宽度”的组件
    width: Dimensions.get('window').width-20,
    height: Dimensions.get('window').width-20,
  }
})