import React from 'react'
import {View, Text, FlatList, Image, Button, ActivityIndicator} from 'react-native'

export default class ProductListScreen extends React.Component{
  /*对象属性*/
  static navigationOptions = { title: '商品列表' }
  static serverUrl = 'http://www.codeboy.com/'
  static prodoctListUrl = 'http://www.codeboy.com/data/product/list.php?pno='    //静态属性，所有的组件实例共用
  pno = 0  //实例属性，即将要加载的数据页号

  /*对象构造方法*/
  constructor(){
    super()
    this.state = {
      plist: []   //商品数组
    }
  }

  /*对象方法*/
  componentDidMount(){  //当组件加载完成，异步请求服务器端商品列表数据
    this.pno++
    fetch(ProductListScreen.prodoctListUrl)
      .then((res)=>{return res.json()})
      .then((result)=>{
        this.setState({ //把服务器响应数据保存入状态数据
          plist: result.data
        })
      })
      .catch((err)=>{ alert(err) })
  }
  _renderItem=(data)=>{   //渲染出一个列表项
    //console.log('一个列表项对应的数据：', data)
    //data:{index: 0, item: {笔记本对象} }
    return (
      <View style={{flexDirection:'row', padding:10, alignItems:'center'}}>
        <Image source={{uri: ProductListScreen.serverUrl + data.item.pic}} style={{width:90, height:90}} resizeMode="stretch"/>
        
        <View style={{flex:1}}>
          <Text numberOfLines={2} ellipsizeMode="tail">{data.item.title}</Text>
          <Text style={{color:'#f00', fontWeight:'bold'}}>单价：{data.item.price}</Text>
        </View>
        
        <Button title="查看详情" onPress={()=>this.props.navigation.navigate('productDetail',{pid: data.item.lid})}/>
      </View>
    )
  }
  _onEndReached=()=>{
    //console.log('列表滚动到底部，该加载更多数据了')
    //alert('列表滚动到底部，该加载更多数据了')
    this.pno++;
    let url = ProductListScreen.prodoctListUrl+this.pno;
    fetch(url)
      .then((res)=>{return res.json()})
      .then((result)=>{
         let plist = this.state.plist //已有数据
         plist = plist.concat(result.data) //拼接新数据
         console.log(plist)
         this.setState({ plist }) //保存入组件状态
      })
      .catch((err)=>{console.log(err)})
  }
  render(){
    return (
      <FlatList data={this.state.plist} renderItem={this._renderItem}  keyExtractor={(item,index)=>index+""} onEndReached={this._onEndReached}>
      </FlatList>
    )
  }
}